import {React} from 'react'
import styles from '../../assets/css/Gallery.module.css';


export default function GallerySection() {
    
    return (
        <div className={styles.GalleryContainer}>
                this is gallery component
        </div>
    )
}
